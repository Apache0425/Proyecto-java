package App;

import View.Marcoprincipal; 

public class App {
    public static void main(String[] args) {
        // Vista.mIniciar(); // Comentar o eliminar esta línea
        Marcoprincipal mainFrame = new Marcoprincipal();
        mainFrame.mIniciardor(); // Inicia la interfaz gráfica
    }
}